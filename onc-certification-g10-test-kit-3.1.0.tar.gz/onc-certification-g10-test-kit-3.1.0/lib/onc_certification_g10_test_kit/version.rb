module ONCCertificationG10TestKit
  VERSION = '3.1.0'.freeze
end
