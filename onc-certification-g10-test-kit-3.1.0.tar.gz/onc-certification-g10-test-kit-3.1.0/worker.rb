require 'inferno'

Inferno::Application.finalize!
